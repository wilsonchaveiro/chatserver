﻿namespace ChatServer.Models.Requests
{
    public class AnswerFriendRequest
    {
        public bool Accepted { get; set; }
    }
}
