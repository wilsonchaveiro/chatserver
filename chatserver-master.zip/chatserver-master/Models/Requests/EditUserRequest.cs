﻿namespace ChatServer.Models.Requests
{
    public class EditUserRequest
    {
        public UserModel User { get; set; }
    }
}
