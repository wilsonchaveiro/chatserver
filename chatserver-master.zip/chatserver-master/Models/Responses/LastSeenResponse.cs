﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChatServer.Models.Responses
{
    public class LastSeenResponse
    {
        public long LastSeenId { get; set; }
    }
}
