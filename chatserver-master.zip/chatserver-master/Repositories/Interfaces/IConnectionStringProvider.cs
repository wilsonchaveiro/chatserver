﻿namespace ChatServer.Repositories.Interfaces
{
    public interface IConnectionStringProvider
    {
        string GetConnectionString();
    }
}
