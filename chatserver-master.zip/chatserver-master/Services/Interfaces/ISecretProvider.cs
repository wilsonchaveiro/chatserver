﻿namespace ChatServer.Services.Interfaces
{
    public interface ISecretProvider
    {
        string GetSecret();
    }
}
